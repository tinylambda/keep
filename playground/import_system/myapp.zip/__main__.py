if __name__ == '__main__':
    print('output from __main__')

