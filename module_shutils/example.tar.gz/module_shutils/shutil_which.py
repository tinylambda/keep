import shutil


print(shutil.which('ls'))
print(shutil.which('tox'))
print(shutil.which('no-sub-program'))

